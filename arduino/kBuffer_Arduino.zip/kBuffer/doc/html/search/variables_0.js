var searchData=
[
  ['data',['data',['../structbuffer__t.html#a974e9a505549d9f8ad9e45cb1b562413',1,'buffer_t']]],
  ['datacount',['datacount',['../structbuffer__t.html#ac7e5e46f55ed6f23cd0c8630ca768f8b',1,'buffer_t']]]
];
