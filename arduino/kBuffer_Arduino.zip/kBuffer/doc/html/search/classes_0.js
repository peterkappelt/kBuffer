var searchData=
[
  ['buffer_5ft',['buffer_t',['../structbuffer__t.html',1,'']]]
];
