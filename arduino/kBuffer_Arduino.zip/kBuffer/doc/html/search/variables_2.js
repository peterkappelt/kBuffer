var searchData=
[
  ['isinitialized',['isInitialized',['../structbuffer__t.html#a226b259859e359bec68028e844a29d13',1,'buffer_t']]]
];
