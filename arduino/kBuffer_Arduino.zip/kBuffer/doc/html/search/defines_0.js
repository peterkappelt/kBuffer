var searchData=
[
  ['buffer_5fenable_5fmean',['BUFFER_ENABLE_MEAN',['../k_buffer_8h.html#a82cc29a07ae3edcaf59d1e15c9ac80cf',1,'kBuffer.h']]],
  ['bufferdatatype',['bufferDatatype',['../k_buffer_8h.html#ae8d6ebfbda34ebc2e00138c04b46e9b1',1,'kBuffer.h']]]
];
