var searchData=
[
  ['writepointer',['writePointer',['../structbuffer__t.html#a497ab79d85c05cf11b3042d27c5a0dbb',1,'buffer_t']]]
];
