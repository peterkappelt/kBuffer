var searchData=
[
  ['readpointer',['readPointer',['../structbuffer__t.html#aae80b6cbad55ddcee74d93a23af7f88f',1,'buffer_t']]]
];
