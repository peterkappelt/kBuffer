var searchData=
[
  ['length',['length',['../structbuffer__t.html#a1892eba2086d12ac2b09005aeb09ea3b',1,'buffer_t']]]
];
