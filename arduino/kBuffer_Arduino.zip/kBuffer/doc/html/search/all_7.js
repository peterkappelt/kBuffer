var searchData=
[
  ['mean_20of_20buffer',['Mean of buffer',['../mean.html',1,'']]]
];
