var searchData=
[
  ['elementlength',['elementLength',['../structbuffer__t.html#ad42232a8a992b5d0eb9daf58d83337ec',1,'buffer_t']]]
];
